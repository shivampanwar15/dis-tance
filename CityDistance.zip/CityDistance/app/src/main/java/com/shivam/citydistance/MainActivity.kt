package com.shivam.citydistance

import android.location.Geocoder
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Place(val name: String, val lat: Double, val lon: Double)

class MainActivity : AppCompatActivity() {

    private lateinit var sourceInput: EditText
    private lateinit var destinationInput: EditText
    private lateinit var calculateButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var resultCard: View
    private lateinit var distanceText: TextView
    private lateinit var roadText: TextView
    private lateinit var placesText: TextView
    private lateinit var errorText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sourceInput = findViewById(R.id.sourceInput)
        destinationInput = findViewById(R.id.destinationInput)
        calculateButton = findViewById(R.id.calculateButton)
        progress = findViewById(R.id.progress)
        resultCard = findViewById(R.id.resultCard)
        distanceText = findViewById(R.id.distanceText)
        roadText = findViewById(R.id.roadText)
        placesText = findViewById(R.id.placesText)
        errorText = findViewById(R.id.errorText)

        calculateButton.setOnClickListener { calculate() }
    }

    private fun calculate() {
        val source = sourceInput.text.toString().trim()
        val destination = destinationInput.text.toString().trim()

        if (source.isEmpty() || destination.isEmpty()) {
            showError("Please enter both source and destination cities.")
            return
        }
        hideKeyboard()
        setLoading(true)

        lifecycleScope.launch {
            try {
                val (from, to) = withContext(Dispatchers.IO) {
                    val a = async { geocode(source) }
                    val b = async { geocode(destination) }
                    a.await() to b.await()
                }
                when {
                    from == null -> showError("Could not find \"$source\". Check the spelling.")
                    to == null -> showError("Could not find \"$destination\". Check the spelling.")
                    else -> {
                        val km = haversineKm(from.lat, from.lon, to.lat, to.lon)
                        val roadKm = withContext(Dispatchers.IO) { roadDistanceKm(from, to) }
                        showResult(from, to, km, roadKm)
                    }
                }
            } catch (e: Exception) {
                showError("Network error. Check your internet connection and try again.")
            } finally {
                setLoading(false)
            }
        }
    }

    /** Shortest (great-circle) distance between two coordinates, in km. */
    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0088 // mean Earth radius, km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    /** City name -> coordinates. OpenStreetMap first, phone's built-in geocoder as fallback. */
    private fun geocode(query: String): Place? {
        try {
            val url = "https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" +
                    URLEncoder.encode(query, "UTF-8")
            val arr = JSONArray(httpGet(url))
            if (arr.length() > 0) {
                val o = arr.getJSONObject(0)
                return Place(
                    o.getString("display_name"),
                    o.getString("lat").toDouble(),
                    o.getString("lon").toDouble()
                )
            }
        } catch (_: Exception) { /* fall through */ }

        return try {
            if (!Geocoder.isPresent()) return null
            @Suppress("DEPRECATION")
            val list = Geocoder(this, Locale.getDefault()).getFromLocationName(query, 1)
            list?.firstOrNull()?.let {
                Place(it.getAddressLine(0) ?: query, it.latitude, it.longitude)
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Driving distance by road (OSRM public server). Returns null if unavailable. */
    private fun roadDistanceKm(from: Place, to: Place): Double? = try {
        val url = "https://router.project-osrm.org/route/v1/driving/" +
                "${from.lon},${from.lat};${to.lon},${to.lat}?overview=false"
        val json = JSONObject(httpGet(url))
        if (json.optString("code") == "Ok")
            json.getJSONArray("routes").getJSONObject(0).getDouble("distance") / 1000.0
        else null
    } catch (_: Exception) {
        null
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", "CityDistanceApp/1.0 (Android)")
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        return try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun showResult(from: Place, to: Place, km: Double, roadKm: Double?) {
        errorText.visibility = View.GONE
        resultCard.visibility = View.VISIBLE
        distanceText.text = String.format(Locale.US, "%,.1f km", km)
        roadText.text = if (roadKm != null)
            String.format(Locale.US, "By road: %,.1f km", roadKm)
        else
            "By road: not available"
        placesText.text = "From: ${from.name}\nTo: ${to.name}"
    }

    private fun showError(msg: String) {
        resultCard.visibility = View.GONE
        errorText.visibility = View.VISIBLE
        errorText.text = msg
    }

    private fun setLoading(loading: Boolean) {
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        calculateButton.isEnabled = !loading
        if (loading) {
            resultCard.visibility = View.GONE
            errorText.visibility = View.GONE
        }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
    }
}
